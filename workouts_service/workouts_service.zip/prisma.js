import { PrismaClient } from "./generated/prisma/index.js";

export const prismaC = new PrismaClient();